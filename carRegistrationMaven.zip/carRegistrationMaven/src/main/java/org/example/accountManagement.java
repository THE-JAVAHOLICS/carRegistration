package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class accountManagement {

    @FXML
    private TextField ID_Username;

    @FXML
    private TextField ID_Password;

    @FXML
    private TextField ID_PasswordConfirm;

    @FXML
    private CheckBox ID_Username_Check;

    @FXML
    private CheckBox ID_Email_Check;

    @FXML
    private CheckBox ID_Password_Check;

    @FXML
    void saveChanges(ActionEvent event) {

    }

}
